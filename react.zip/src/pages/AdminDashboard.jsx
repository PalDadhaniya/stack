import React, { useState } from 'react'
import UserData from '../utils/UserData.json'

const AdminDashboard = () => {
    const [search, setSearch] = useState('')
    const [formData, setFormData] = useState({
        email: '',
        name: "",
        role: "",
    })

    const searchData = UserData.filter((user) => user.name.toLowerCase().includes(search.toLowerCase()
        //  || user.email.toLowerCase().includes(search.toLowerCase())
    ))

    const EditCustomer = (e) => {
        e.preventDafault
    }

    const handlechange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const deleteCustomer = (e) =>{
        UserData.filter((user) => user.email !== e.email)
    }

    const handleSubmit = (e) => {
        e.preventDefault()
        console.log("formData", formData)
        // UserData.push(...UserData, formData)
    }

    return (
        <>
        {console.log("uSerData",UserData)}
            <div className='text-2xl font-bold mb-3'> Admin Panel</div>
            <input name='search' placeholder='Search' className='mb-2 border border-black placeholder:text-black placeholder:pl-2 pl-2' onChange={(e) => setSearch(e.target.value)} value={search} />
            <div className='grid grid-cols-5 border border-black text-white'>
                <h1 className='bg-black'>Name</h1>
                <div className='bg-black'>Email</div>
                <div className='bg-black'>Role</div>
            </div>

            {searchData.length === 0 && <h1>No data found</h1>}
            {searchData.map((user) => (<>
                <div className='grid grid-cols-5 border border-black text-white'>
                    <div className='bg-blue-400'>{user.name}</div>
                    <div className='bg-green-400'>{user.email}</div>
                    <div className='bg-red-400'>{user.role}</div>
                    <div><button className=' text-black' onClick={deleteCustomer(user)}>Delete</button></div>
                    <div><button className=' text-black' onClick={EditCustomer(user)}>Edit</button></div>

                </div>
            </>))}

            <div>
                <div>Add Data</div>
                <input
                    name="name"
                    value={formData.name}
                    onChange={handlechange}
                    placeholder="Name"
                    className='mb-2 border border-black placeholder:text-black placeholder:pl-2 pl-2'
                />
                <input
                    name="email"
                    value={formData.email}
                    onChange={handlechange}
                    placeholder="Email"
                    className='mb-2 border border-black placeholder:text-black placeholder:pl-2 pl-2'
                />
                <input
                    name="role"
                    value={formData.role}
                    onChange={handlechange}
                    placeholder="Role"
                    className='mb-2 border border-black placeholder:text-black placeholder:pl-2 pl-2'
                />
                <button onClick={handleSubmit}>Submit</button>
            </div>
        </>
    )
}

export default AdminDashboard