import React from 'react';
import { useNavigate } from 'react-router-dom';
import products from '../utils/Product.json';

const Home = () => {
  const navigate = useNavigate();
  
const addtocart= (product)=>{
  event.stopPropagation();
  localStorage.setItem("cart",JSON.stringify(product))
  navigate('/cart')
}

const addtoproducts= (product)=>{
  localStorage.setItem("product",JSON.stringify(product))
  navigate('/productInnerPage') 
}
  return (<>
  <div className='text-black font-semibold mb-4'>User home page</div>
        <div className='grid grid-cols-4 border border-black text-white'>
        <h1 className='bg-black'>Name</h1>
        <div className='bg-black'>Description</div>
        <div className='bg-black'>Price</div>
      </div>
    {products.map((product,index)=>(
      <div className='grid grid-cols-4 border border-black  ' key={product.id} onClick={() => addtoproducts(product)}>
        <h1 className='bg-blue-400'>{product.name}</h1>
        <div className='bg-green-500'>{product.description}</div>
        <div className='bg-red-500'>{product.price}</div>
        <div><button className='bg-transparent text-black'  onClick={(e) => addtocart(e, product)} >Add to cart</button></div>
      </div>
    ))}
    </>
  )
}

export default Home