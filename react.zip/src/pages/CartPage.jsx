import React from 'react'
import ProductData from '../utils/Cart.json'

const CartPage = () => {
  return (<>
    <div>CartPage</div>
    {ProductData.map(product => (
      <div className='grid grid-rows-4 w-48 border border-black rounded-md ' key={product?.id} >
        <h1 className='bg-transparent '>{product?.name}</h1>
        <div className='bg-green-500'>{product?.description}</div>
        <div className='bg-red-500'>{product?.price}</div>
      </div>
    ))}

  </>
  )
}

export default CartPage