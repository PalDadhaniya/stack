import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'

const ProductInnerPage = () => {
  const [product,setProduct] = useState(null)
  const [cart,setCart] = useState(null)
  console.log("cart",cart)
const navigate = useNavigate()
  useEffect(()=>{
    setProduct(JSON.parse(localStorage.getItem("product")))
    setCart(JSON.parse(localStorage.getItem("cart")))

  },[])

  const addtocart= (product)=>{
    console.log("product",product)
    localStorage.setItem("product",JSON.stringify(product))
    navigate('/cart')
  }
  return (
    <>  
    <div className='h-auto  bg-transparent shadow-slate-500 border p-4 border-black mb-3 relative' onClick={() => navigate('/cart')}>Cart icon
    <span className='absolute -mt-2 bg-black text-white rounded-xl p-[0.5] m-1'></span></div>
    <h2 className='font-bold'>Product Inner Page</h2>
      <div className='grid grid-rows-4 w-48 border border-black rounded-md' key={product?.id} >
        <h1 className='bg-transparent '>{product?.name}</h1>
        <div className='bg-green-500'>{product?.description}</div>
        <div className='bg-red-500'>{product?.price}</div>
        <div><button className='bg-black text-white' onClick={() => addtocart(product)} >Add to cart</button></div>
      </div>
      </>
  )
}

export default ProductInnerPage