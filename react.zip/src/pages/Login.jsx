import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import UserData from '../utils/UserData.json';

const Login = () => {
    const [formData, setFormData] = useState({
        email: '',
        password: '',
    })
    const [errors, setErrors] = useState({});
    const [loginError, setLoginError] = useState("");
    const navigate = useNavigate();

    const handlechange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };
    const handleValidate = () => {
        const newError = {};

        if (!formData.email) {
            newError.email = "Email is required";
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            newError.email = "Invalid email format";
        }
        if (!formData.password) {
            newError.password = "Password is required";
        }
        return newError
    }
    const handleSubmit = (e) => {
        console.log("UserData",UserData)
        e.preventDefault();
        const validate = handleValidate()
        
        setErrors(validate);
        
        if (Object.keys(validate).length === 0) {
            const storedUser = UserData?.find((user) => user.email === formData.email && user.password === formData.password && user.role === 'Admin'); 
            console.log("storedUser",storedUser)
            if (
                storedUser &&
                storedUser.email === formData.email &&
                storedUser.password === formData.password
            ) {
                localStorage.setItem("user", JSON.stringify(storedUser));
                navigate("/adminDashboard");
            } else {
                setLoginError("Invalid email or password");
            }
        }
    }
    return (

        <div className="max-w-md mx-auto p-6 mt-20 shadow-lg rounded-xl bg-blue-100">
            <h2 className="text-2xl font-bold mb-4">Login</h2>
            <div className=''>
                <form onSubmit={handleSubmit} className="space-y-4 grid ">
                    <input
                        name="email"
                        value={formData.email}
                        onChange={handlechange}
                        placeholder="Email"
                        className="input"
                    />
                    {errors.email && <p className="text-red-500">{errors.email}</p>}

                    <input
                        name="password"
                        type="password"
                        value={formData.password}
                        onChange={handlechange}
                        placeholder="Password"
                        className="input"
                    />
                    {errors.password && <p className="text-red-500">{errors.password}</p>}

                    {loginError && <p className="text-red-500">{loginError}</p>}

                    <button
                        type="submit"
                        className="btn w-full bg-green-500 text-white py-2 rounded"
                    >
                        Login
                    </button>
                </form>
            </div>
        </div>
    )
}

export default Login