import { useEffect, useState } from 'react';
import { Route, Routes } from 'react-router-dom';
import './App.css';
import AdminDashboard from './pages/AdminDashboard';
import CartPage from './pages/CartPage';
import Home from './pages/Home';
import Login from './pages/Login';
import ProductInnerPage from './pages/ProductInnerPage';

function App() {
  const [count, setCount] = useState(0)
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = JSON.parse(localStorage.getItem("user"));
    if (storedUser) setUser(storedUser);
  }, []);
  return (
    <>
      <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login setUser={setUser} />} />
      <Route path="/productInnerPage" element={<ProductInnerPage />} />
      <Route path="/adminDashboard" element={<AdminDashboard />} />
      <Route path="/cart" element={<CartPage />} />

    </Routes>
    </>
  )
}

export default App
