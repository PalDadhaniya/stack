import React, { useEffect } from 'react';
import AdminDashboard from '../pages/AdminDashboard';
import Login from '../pages/Login';

const protectedRoute = () => {
    useEffect(() => {
        const storedUser = JSON.parse(localStorage.getItem("user"));
        if (storedUser) setUser(storedUser);
    }, [])
    return (<>
        {storedUser ? <AdminDashboard /> : <Login />}
    </>
  )
}

export default protectedRoute